export const logoutcall = async (dispatch) => {
  dispatch({type: "LOGIN_START"});
}
